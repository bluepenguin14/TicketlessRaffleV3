/*
=================================================
 Ticketless Raffle v3

 Admin Dashboard JavaScript

 Responsibilities:
 - Load raffle stats
 - Add manual entrants
 - Draw winners
 - Export CSV
 - Reset raffle

=================================================
*/


// -----------------------------------------------
// Elements
// -----------------------------------------------

const loginSection =
    document.getElementById("loginSection");


const dashboardSection =
    document.getElementById("dashboardSection");


const loginButton =
    document.getElementById("loginButton");


const adminPassword =
    document.getElementById("adminPassword");


const loginMessage =
    document.getElementById("loginMessage");

const entrantCount =
    document.getElementById("entrantCount");


const totalTickets =
    document.getElementById("totalTickets");


const winnerCount =
    document.getElementById("winnerCount");
const totalCollected = document.getElementById("totalCollected");
const winnerShare = document.getElementById("winnerShare");
const organizationShare = document.getElementById("organizationShare");
const legacyAmountWarning = document.getElementById("legacyAmountWarning");
const money = cents => `$${(Number(cents || 0) / 100).toFixed(2)}`;


const winnerDisplay =
    document.getElementById("winnerDisplay");


const winnerHistory =
    document.getElementById("winnerHistory");


const message =
    document.getElementById("adminMessage");


const searchEntrants =
    document.getElementById("searchEntrants");


let allEntrants = [];

loginButton.addEventListener(
"click",

async()=>{


    const response =
    await fetch(
        "/api/auth/login",
        {

            method:"POST",

            credentials:"include",

            headers:{

                "Content-Type":
                "application/json"

            },

            body:
            JSON.stringify({

                password:
                adminPassword.value

            })

        }
    );


    const result =
        await response.json();



    if(result.success){


        loginSection.style.display =
            "none";


        dashboardSection.style.display =
            "block";


            await loadDashboard();

            await loadEntrants();



    }
    else {


        loginMessage.textContent =
            "Invalid password";


    }


});


// -----------------------------------------------
// Load Dashboard
// -----------------------------------------------

async function loadDashboard(){


    try {


        const response = await fetch(
    "/api/admin/stats",
    {
        credentials: "include"
    }
);


        const result =
            await response.json();



        if(result.success){


            entrantCount.textContent =
                result.stats.entrants;


            totalTickets.textContent =
                result.stats.totalTickets;


            winnerCount.textContent =
                result.stats.winners;
            totalCollected.textContent = money(result.stats.totalCollectedCents);
            winnerShare.textContent = money(result.stats.winnerShareCents);
            organizationShare.textContent = money(result.stats.organizationShareCents);
            if (result.stats.entriesMissingAmount > 0) {
                legacyAmountWarning.style.display = "block";
                legacyAmountWarning.textContent = `${result.stats.entriesMissingAmount} older entrant(s) have no recorded payment amount. They are excluded from the dollar totals until you edit them and select the package actually paid for.`;
            } else {
                legacyAmountWarning.style.display = "none";
                legacyAmountWarning.textContent = "";
            }



            displayWinners(
                result.winnerHistory
            );

            

        }


    }
    catch(error){

        console.error(error);

    }


}


// -----------------------------------------------
// Load Entrants
// -----------------------------------------------

async function loadEntrants() {


    try {

        const response = await fetch(
            "/api/admin/entrants",
            {
                credentials: "include"
            }
        );

        const result = await response.json();

        if (!result.success) {

            return;

        }

        // Save all entrants for searching/sorting
        allEntrants = result.entrants;

        // Display them
        renderEntrants(allEntrants);

    }

    catch (error) {

    console.error("loadEntrants error:", error);

}

}



// -----------------------------------------------
// Save/Add Entrant
// -----------------------------------------------

document
.getElementById("saveEntrantButton")
.addEventListener(
"click",

async()=>{

	
    const name =
        document
        .getElementById("adminName")
        .value;


    const email =
        document
        .getElementById("adminEmail")
        .value;


    const packageQuantities = {
        1: Number(document.getElementById("adminQty1").value || 0),
        5: Number(document.getElementById("adminQty5").value || 0),
        10: Number(document.getElementById("adminQty10").value || 0)
    };



    try {


     const response =
         await fetch(
        "/api/admin/add",
        {
            method:"POST",

            credentials:"include",

            headers:{
                "Content-Type":"application/json"
            },

            body:JSON.stringify({

                name,

                email,

                packageQuantities

            })
        }
    );



        const result =
            await response.json();



        message.textContent =
            result.success
            ?
            "Entrant added successfully."
            :
            result.error;


        if(result.success){

await loadDashboard();

await loadEntrants();

    // Clear manual entrant form
    document
    .getElementById("adminName")
    .value = "";

    document
    .getElementById("adminEmail")
    .value = "";

    document.getElementById("adminQty1").value = "0";
    document.getElementById("adminQty5").value = "0";
    document.getElementById("adminQty10").value = "1";

}
        




    }

    catch(error){

        console.error(error);

    }


});


// -----------------------------------------------
// Draw Winner
// -----------------------------------------------

document
.getElementById("drawButton")
.addEventListener(
"click",

async()=>{

    if(
        !confirm(
        "Draw a winner now?"
        )
    ){

        return;

    }

    const drawButton =
        document.getElementById("drawButton");


    // Prevent double-clicks
    drawButton.disabled = true;

    drawButton.textContent =
        "Drawing...";


    winnerDisplay.textContent =
        "Drawing winner...";


    try {


        const response =
            await fetch(
                "/api/admin/draw",
                {
                    method:"POST",

                    credentials:"include"
                }
            );


        const result =
            await response.json();


        if(result.success){


            winnerDisplay.innerHTML =

            `
            <h2>
                ${result.winner.name}
            </h2>

            <p>Winning Entries: ${result.winner.tickets}</p>
            <p>Total Collected: ${money(result.winner.totalCollectedCents)}</p>
            <p>Winner's Half: ${money(result.winner.winnerShareCents)}</p>
            <p>Veterans' Half: ${money(result.winner.organizationShareCents)}</p>
            `;


            await loadDashboard();


        }

        else {


            winnerDisplay.textContent =
                result.error;


        }


    }

    catch(error){


        console.error(error);


        winnerDisplay.textContent =
            "Unable to draw winner. Please try again.";


    }


    finally {


        drawButton.disabled = false;


        drawButton.textContent =
            "Draw Winner";


    }

});



// -----------------------------------------------
// Export CSV
// -----------------------------------------------

document
.getElementById("exportButton")
.addEventListener(
"click",

()=>{

   window.location.href =
        "/api/admin/export";
   

});




// -----------------------------------------------
// Reset Raffle
// -----------------------------------------------

document
.getElementById("resetButton")
.addEventListener(
"click",

async()=>{

    // First confirmation

    if(
        !confirm(
        "WARNING:\n\n" +
        "This will remove ALL current entrants " +
        "from the active raffle.\n\n" +
        "Winner history will NOT be deleted.\n\n" +
        "Do you want to continue?"
        )
    ){

        return;

    }


    // Second confirmation

    const confirmation =
        prompt(
            'To confirm the reset, type "RESET" below. MUST be in ALL CAPS!'
        );


    if(
        confirmation !== "RESET"
    ){

        alert(
            "Reset cancelled."
        );

        return;

    }


    const resetButton =
        document.getElementById("resetButton");


    // Prevent double-clicks

    resetButton.disabled = true;

    resetButton.textContent =
        "Resetting...";


    try {


        const response =
            await fetch(
                "/api/admin/reset",
                {
                    method:"POST",

                    credentials:"include"
                }
            );


        const result =
            await response.json();


        if(result.success){


            alert(
                "Raffle reset complete."
            );


            await loadDashboard();

            await loadEntrants();


        }

        else {


            alert(
                result.error ||
                "Unable to reset raffle."
            );


        }


    }

    catch(error){


        console.error(error);


        alert(
            "Unable to reset raffle. Please try again."
        );


    }


    finally {


        resetButton.disabled = false;


        resetButton.textContent =
            "Reset Raffle";


    }

});


// -----------------------------------------------
// Render Entrants
// -----------------------------------------------

function renderEntrants(entrants) {

    const tableBody =
        document.getElementById("entrantTableBody");

    tableBody.innerHTML = "";

    entrants.forEach(entrant => {

        const row =
            document.createElement("tr");

        row.innerHTML = `

            <td>${entrant.name}</td>

            <td>${entrant.email || ""}</td>

            <td>${entrant.tickets}</td>

            <td>${Number.isInteger(entrant.amountPaidCents) ? money(entrant.amountPaidCents) : "Not recorded"}</td>

            <td>${new Date(
                entrant.timestamp
            ).toLocaleString()}</td>

            <td>

                <button
                    class="editButton"
                    data-id="${entrant.id}">
                    ✏️
                </button>

            </td>

            <td>

                <button
                    class="deleteButton"
                    data-id="${entrant.id}">
                    🗑
                </button>

            </td>

        `;

        tableBody.appendChild(row);

row.querySelector(".editButton")
    .addEventListener(
        "click",
        () => openEditModal(entrant)
    );

        row.querySelector(".deleteButton")
    .addEventListener(

        "click",

        () => deleteEntrant(entrant.id)

    );

    });

}



// -----------------------------------------------
// Search Entrants
// -----------------------------------------------

function filterEntrants() {

    const search =
        searchEntrants.value
        .toLowerCase()
        .trim();

    const filtered =
        allEntrants.filter(entrant =>

            entrant.name
                .toLowerCase()
                .includes(search)

            ||

            (entrant.email || "")
                .toLowerCase()
                .includes(search)

        );

    renderEntrants(filtered);

}


// -----------------------------------------------
// Delete Entrant
// -----------------------------------------------

async function deleteEntrant(id) {

    const confirmed = confirm(
        "Are you sure you want to delete this entrant?"
    );

    if (!confirmed) {
        return;
    }

    // existing delete code continues here...

    try {

        const response = await fetch(

            `/api/admin/entrant/${id}`,

            {
                method: "DELETE",
                credentials: "include"
            }

        );

        const result = await response.json();

        if (!result.success) {

            alert(result.error);
            return;

        }

        await loadDashboard();
        await loadEntrants();

    }

    catch (error) {

        console.error(error);
        alert("Unable to delete entrant.");

    }

}

// -----------------------------------------------
// Open Edit Modal
// -----------------------------------------------

function openEditModal(entrant) {

    document.getElementById("editId").value =
        entrant.id;

    document.getElementById("editName").value =
        entrant.name;

    document.getElementById("editEmail").value =
        entrant.email || "";

    const quantities = entrant.packageQuantities || (
        Number.isInteger(entrant.amountPaidCents) && [1, 5, 10].includes(Number(entrant.packagePrice))
            ? { [Number(entrant.packagePrice)]: 1 }
            : {}
    );
    // Never infer a payment package for older records without recorded payment details.
    document.getElementById("editQty1").value = quantities[1] ?? 0;
    document.getElementById("editQty5").value = quantities[5] ?? 0;
    document.getElementById("editQty10").value = quantities[10] ?? 0;

    document.getElementById("editModal").style.display = "flex";

}

// -----------------------------------------------
// Save Edited Entrant
// -----------------------------------------------

async function saveEditedEntrant() {

    const id =
        document.getElementById("editId").value;

    const name =
        document.getElementById("editName").value.trim();

    const email =
        document.getElementById("editEmail").value.trim();

    const packageQuantities = {
        1: Number(document.getElementById("editQty1").value || 0),
        5: Number(document.getElementById("editQty5").value || 0),
        10: Number(document.getElementById("editQty10").value || 0)
    };

    try {

        const response = await fetch(

            `/api/admin/entrant/${id}`,

            {

                method: "PUT",

                credentials: "include",

                headers: {

                    "Content-Type": "application/json"

                },

                body: JSON.stringify({

                    name,
                    email,
                    packageQuantities

                })

            }

        );

        const result =
            await response.json();

        if (!result.success) {

            alert(result.error);
            return;

        }

        document.getElementById("editModal").style.display =
            "none";

        await loadDashboard();
        await loadEntrants();

    }

    catch (error) {

        console.error(error);

        alert("Unable to update entrant.");

    }

}

// -----------------------------------------------
// Display Winners
// -----------------------------------------------

function displayWinners(winners){

    if(
        !winners ||
        winners.length === 0
    ){

        winnerHistory.textContent =
            "No winners yet.";

        return;

    }


    winnerHistory.innerHTML =

        winners
        .map(

            (winner, index) =>

            `
            <div class="winner-history-row">

                <div class="winner-number">
                    ${index + 1}
                </div>

                <div class="winner-info">

                    <strong>
                        ${winner.name}
                    </strong>

                    <span>
                        ${winner.date || ""}
                    </span>

                </div>

            </div>
            `

        )

        .join("");

}

// -----------------------------------------------
// Startup
// -----------------------------------------------

searchEntrants.addEventListener(
    "input",
    filterEntrants
);

document
.getElementById("cancelEditButton")
.addEventListener(

    "click",

    () => {

        document.getElementById("editModal").style.display =
            "none";

    }

);

document
.getElementById("saveEditButton")
.addEventListener(

    "click",

    saveEditedEntrant

);

// -----------------------------------------------
// Dark Mode
// -----------------------------------------------

const darkModeButton =
    document.getElementById(
        "darkModeButton"
    );


function updateDarkModeButton(){

    if(
        document.body.classList.contains(
            "dark-mode"
        )
    ){

        darkModeButton.textContent =
            "☀️ Light Mode";

    }

    else {

        darkModeButton.textContent =
            "🌙 Dark Mode";

    }

}


// Load saved Dark Mode preference

if(
    localStorage.getItem(
        "darkMode"
    ) === "true"
){

    document.body.classList.add(
        "dark-mode"
    );

}


updateDarkModeButton();


// Toggle Dark Mode

darkModeButton.addEventListener(
    "click",

    () => {

        document.body.classList.toggle(
            "dark-mode"
        );


        const isDarkMode =
            document.body.classList.contains(
                "dark-mode"
            );


        localStorage.setItem(
            "darkMode",
            isDarkMode
        );


        updateDarkModeButton();

    }

);

// -----------------------------------------------
// Large Text Mode
// -----------------------------------------------

const largeTextButton =
    document.getElementById(
        "largeTextButton"
    );


function updateLargeTextButton(){

    if(
        document.body.classList.contains(
            "large-text"
        )
    ){

        largeTextButton.textContent =
            "🔤 Normal Text";

    }

    else {

        largeTextButton.textContent =
            "🔠 Large Text";

    }

}


// Load saved Large Text preference

if(
    localStorage.getItem(
        "largeText"
    ) === "true"
){

    document.body.classList.add(
        "large-text"
    );

}


updateLargeTextButton();


// Toggle Large Text Mode

largeTextButton.addEventListener(
    "click",

    () => {

        document.body.classList.toggle(
            "large-text"
        );


        const isLargeText =
            document.body.classList.contains(
                "large-text"
            );


        localStorage.setItem(
            "largeText",
            isLargeText
        );


        updateLargeTextButton();

    }

);

// -----------------------------------------------
// QR Code Generator
// -----------------------------------------------

const raffleUrl =
    "https://raffle-app-kjg2.onrender.com";


const qrCodeContainer =
    document.getElementById(
        "qrCode"
    );


const downloadQrButton =
    document.getElementById(
        "downloadQrButton"
    );


// Generate QR Code

if(qrCodeContainer){

    new QRCode(
        qrCodeContainer,
        {
            text: raffleUrl,

            width: 250,

            height: 250,

            correctLevel:
                QRCode.CorrectLevel.H
        }
    );

}


// Download QR Code

if(downloadQrButton){

    downloadQrButton.addEventListener(
        "click",

        () => {

            const qrImage =
                qrCodeContainer
                .querySelector("img");


            if(!qrImage){

                alert(
                    "QR code is not ready yet."
                );

                return;

            }


            const link =
                document.createElement(
                    "a"
                );


            link.href =
                qrImage.src;


            link.download =
                "ticketless-raffle-qr-code.png";


            document.body.appendChild(
                link
            );


            link.click();


            document.body.removeChild(
                link
            );

        }

    );

}
// -----------------------------------------------
// Print QR Sign
// -----------------------------------------------

const printQrButton =
    document.getElementById(
        "printQrButton"
    );


const qrPrintCode =
    document.getElementById(
        "qrPrintCode"
    );


if(qrPrintCode){

    new QRCode(
        qrPrintCode,
        {
            text: raffleUrl,

            width: 500,

            height: 500,

            correctLevel:
                QRCode.CorrectLevel.H
        }
    );

}


if(printQrButton){

    printQrButton.addEventListener(
        "click",

        () => {

            window.print();

        }

    );

}


